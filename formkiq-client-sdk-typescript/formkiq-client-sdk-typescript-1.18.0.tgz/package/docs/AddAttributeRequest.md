# AddAttributeRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attribute** | [**AddAttribute**](AddAttribute.md) |  | [default to undefined]

## Example

```typescript
import { AddAttributeRequest } from 'formkiq-client-sdk-typescript';

const instance: AddAttributeRequest = {
    attribute,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
