# EntityTypeNamespace

Entity Type namespace

## Enum

* `Preset` (value: `'PRESET'`)

* `Custom` (value: `'CUSTOM'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
