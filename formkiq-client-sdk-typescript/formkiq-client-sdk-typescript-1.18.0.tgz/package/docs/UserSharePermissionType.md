# UserSharePermissionType

User Share Permission Type

## Enum

* `Group` (value: `'GROUP'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
