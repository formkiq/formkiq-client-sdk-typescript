# AddDocumentActionsResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** | Document Action message | [optional] [default to undefined]

## Example

```typescript
import { AddDocumentActionsResponse } from 'formkiq-client-sdk-typescript';

const instance: AddDocumentActionsResponse = {
    message,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
