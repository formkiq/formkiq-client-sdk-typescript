# AddDocumentSyncService

Add Document Sync Service

## Enum

* `Fulltext` (value: `'FULLTEXT'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
