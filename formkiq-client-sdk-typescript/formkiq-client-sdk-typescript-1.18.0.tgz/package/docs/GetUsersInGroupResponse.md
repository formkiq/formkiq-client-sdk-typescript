# GetUsersInGroupResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**next** | **string** | Next page of results token | [optional] [default to undefined]
**users** | [**Array&lt;User&gt;**](User.md) | List of users | [optional] [default to undefined]

## Example

```typescript
import { GetUsersInGroupResponse } from 'formkiq-client-sdk-typescript';

const instance: GetUsersInGroupResponse = {
    next,
    users,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
