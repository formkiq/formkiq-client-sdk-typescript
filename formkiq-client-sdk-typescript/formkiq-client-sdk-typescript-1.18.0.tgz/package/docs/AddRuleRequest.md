# AddRuleRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule** | [**AddRule**](AddRule.md) |  | [optional] [default to undefined]

## Example

```typescript
import { AddRuleRequest } from 'formkiq-client-sdk-typescript';

const instance: AddRuleRequest = {
    rule,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
