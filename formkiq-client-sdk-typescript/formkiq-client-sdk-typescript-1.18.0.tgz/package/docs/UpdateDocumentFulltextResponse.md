# UpdateDocumentFulltextResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** | Full text processing message | [optional] [default to undefined]

## Example

```typescript
import { UpdateDocumentFulltextResponse } from 'formkiq-client-sdk-typescript';

const instance: UpdateDocumentFulltextResponse = {
    message,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
