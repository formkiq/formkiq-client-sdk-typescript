# OpaPolicyAttributeLt

Attribute less than criteria

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**numberValue** | **number** | The value to compare the Attribute Key value to | [optional] [default to undefined]

## Example

```typescript
import { OpaPolicyAttributeLt } from 'formkiq-client-sdk-typescript';

const instance: OpaPolicyAttributeLt = {
    numberValue,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
